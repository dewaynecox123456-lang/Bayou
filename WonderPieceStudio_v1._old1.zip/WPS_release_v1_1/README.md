# Wonder Piece Studio — Technical Publications

This is the v1.1 static site bundle, styled with a subtle Bayou theme.
**Pages**
- site/index.html (landing with checkout buttons + Netlify form)
- site/terms.html
- site/payments/*.html (redirect stubs)

**Deploy**
Drag the `site/` folder into Netlify or connect the repo root to build.
